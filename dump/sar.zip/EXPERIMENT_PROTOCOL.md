# Experimental protocol

## Corpus D
D is a pooled, bounded passage corpus built from training-split material across the six datasets named in the methodology: WikiHop, HotpotQA, MuSiQue, Natural Questions, TriviaQA and StrategyQA. Duplicate passage content is removed. Each passage is chunked to at most 350 tokenizer tokens with 50-token overlap and the corpus is capped at 100,000 passages. No development/final-evaluation records are used to build D. `scripts/prepare_corpus.py` creates D and a manifest containing source hashes and chunking settings.

The main benchmark freezes D for a run. The SAR index is incrementally synchronised after each completed retrieval process as required by the methodology; with a frozen benchmark corpus the normal result is zero changes. The exact dense vector matrix remains disk-backed via `local_memmap`, avoiding full-corpus RAM materialisation. All vectors are stored locally because the SAR score must be computed over every corpus document; an approximate nearest-neighbour query cannot evaluate the composite SAR score exactly.

## Splits
Tuning uses a deterministic 10% holdout from each dataset's training split. The labeled final evaluation defaults to each dataset's public `dev` split because many test sets do not expose answer labels. An explicitly labeled test file can be supplied by changing `data.final_split`; the run metadata records the actual split.

## Parameter selection
The six datasets share one global SAR configuration. For each K in {3,5,10}, Bayesian optimization runs 3 initialization trials plus 7 Bayesian trials. Each trial executes the full MIGRES loop on 8 tuning questions per dataset. The validation objective is the mean final raw retrieval Recall@K averaged across datasets. The chosen K and `(alpha,beta,gamma)` are frozen before final evaluation.

## Baseline replacement rule
SAR is `Sentence Transformer -> state-aware algorithm -> SAR score -> Top-K`. Every other method replaces this complete retrieval stack. Only `sentence_transformer_search` uses the project Sentence Transformer. MIGRES still generates retrieval queries for every baseline, and the same filtering, evidence extraction, missing-information update, and stopping path are applied after retrieval.

Baselines: BM25, MMR, DPR, Contriever, SPLADE, ColBERTv2, Sentence Transformer Search, and InfoGain-RAG when a compatible published checkpoint is configured. MMR is a lexical BM25-candidate MMR implementation and does not use sentence-transformers. InfoGain-RAG is an adapter requiring a compatible trained reranker checkpoint; it uses BM25 only as its first-stage candidate generator and does not use sentence-transformers. When no checkpoint is configured, the baseline notebook reports InfoGain-RAG as unavailable rather than silently replacing it with another model.

Because the same MIGRES cross-encoder filter is applied after each method, raw retrieval ranking is evaluated before filtering, while downstream answer quality is evaluated after filtering. Filter retention and top-1 survival are recorded separately so a downstream result is not mistaken for a raw-ranker result.

## Ablation
Weights are frozen from the full SAR validation selection; ablations are not retuned. In `without-*` variants, the remaining weights are renormalized. Question-Only uses the original question inside SAR and is therefore distinct from the Sentence Transformer baseline, which receives the current MIGRES query set. Gap-Only and Novelty-Only are included as single-signal controls.

## Accuracy and RGB
Answer Accuracy is normalized exact-answer correctness with gold aliases. It is not contains-match and not an LLM judge. RGB is retained as a downstream robustness suite only. RGB passages are not silently added to D, because doing so would change the retrieval benchmark. Negative rejection is therefore output-level; the retrievers use fixed Top-K and have no abstention threshold.

## Statistical reporting and cost
Each dataset run records the number of evaluated questions, one fixed execution seed, index build time, retrieval latency, embedding/scoring time, documents scored, similarity calculations, iterations to termination, LLM call count, estimated LLM token count and peak RSS. Method comparisons on common question IDs use paired bootstrap confidence intervals and paired randomisation tests.
