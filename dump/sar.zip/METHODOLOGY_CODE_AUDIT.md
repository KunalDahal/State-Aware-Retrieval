# Methodology ↔ Code Audit

This audit tracks the supplied methodology against the executable project. The methodology describes SAR as a direct retrieval replacement inside MIGRES, with a fixed Sentence Transformer representation, a state-aware score using question relevance, gap coverage, and evidence novelty, Top-K selection, iterative state updates, baseline comparison, ablation, retrieval metrics, iterative metrics, downstream RAG/RGB, and computational-cost evaluation.

## Closed gaps

| Area | Before | Current implementation |
|---|---|---|
| Baselines inside MIGRES | Baselines were one-shot/original-question paths | `RetrieverSearchProvider` is shared by SAR and baselines; MIGRES-generated queries are routed through the selected baseline, then the same upstream filtering, QueryForward, evidence extraction, gap update, and stopping path is used. |
| SAR decomposition | Retrieval logic was coupled | SAR is explicitly `Sentence Transformer -> state-aware algorithm -> SAR score -> Top-K`. |
| Sentence Transformer baseline | Not clearly isolated | `sentence_transformer_search` is a separate baseline and is the only baseline that constructs the project Sentence Transformer embedding stack. |
| DPR | Stub | Native DPR question/context encoder implementation with persistent document cache. |
| Contriever | Stub | Native Transformer mean-pool + normalized dense index. |
| SPLADE | Stub | Native masked-LM sparse expansion with sharded on-disk CSR cache. |
| ColBERTv2 | Stub | Token-level late-interaction implementation with sharded token cache and MaxSim scoring. |
| Accuracy | Missing | Added alongside EM and token-level F1. Aggregate answer evaluation excludes records without gold answers instead of counting them as incorrect. |
| RGB | Missing | Added a four-setting evaluator (`noise_robustness`, `negative_rejection`, `information_integration`, `counterfactual_robustness`) with an explicit input/output contract. |
| Dynamic weights | Undefined/refused | Dynamic mode now requires a named rule. `state_balanced_v1` is explicitly marked as a project-defined extension because the supplied methodology does not define a mathematical dynamic rule. |
| Bayesian objective | Not defined | `mean_recall_at_k` is explicit in `configs/experiments.yaml` and implemented by the parameter-selection notebook. This is an executable project choice, not a claim that the supplied methodology specified the objective. |
| Corpus synchronization | Only `prepare()` | SAR performs the required corpus check at iteration boundaries: before each subsequent retrieval (after MIGRES has completed the prior state update) and once after the final iteration; a sync history is recorded. |
| SAR memory usage | Full dense matrix copied into RAM | `DiskMemmapVectorStore` stores dense vectors on disk and streams chunks for scoring. Lazy corpus loading avoids keeping full document text in RAM, and corpus IDs are exposed as a lazy sequence. |
| Baseline full-corpus memory | BM25 kept Python term-frequency lists | BM25 now uses a disk-backed inverted index; dense baseline document representations and sparse/ColBERT caches are also chunked/sharded on disk. |
| Corpus update detection | Re-syncing reused the already-loaded corpus object | Every SAR iteration checks the corpus source signature and reloads the corpus only when the source changes, then rebinds the SAR retriever to the refreshed corpus before embedding synchronization. |
| Dataset split control | Split mainly metadata | `load_questions(..., split=...)` now handles split keys (`validation`, `dev`, `test`, etc.) and row-level split tags when present. Pipelines/scripts pass the configured split. |
| Validation → frozen test protocol | Not executable end-to-end | Parameter notebook writes a frozen `selected_config.json`; baseline/ablation/downstream notebooks can reuse the frozen `K` and SAR weights for test runs. |
| Separate experimental notebooks | One all-in-one notebook | Seven notebooks, one for each §5.6.1–§5.6.7 design. The old combined notebook was removed. |
| Retrieval evaluation | Partial | Recall@K, Precision@K, Hit@K, MRR, nDCG@K implemented with explicit relevance-annotation coverage. |
| Iterative evaluation | Partial | Cumulative recall, marginal gain, new-document rate, retrieval overlap implemented. |
| Cost evaluation | Partial | Latency, embedding/scoring time, documents scored, similarity calculations, overhead helper, and peak RSS metadata are recorded. |
| Reproducibility | Partial | Configuration snapshot, corpus version, dataset file hash, split, synchronization history, retrieval method/score, package versions, run status, and upstream code hashes are recorded. |

## Remaining methodology ambiguities / constraints (not silently invented)

### 1. Dynamic weighting formula
The methodology says dynamic weights “may change according to the current retrieval state” but does not provide the actual function. The code therefore requires a named rule and labels `state_balanced_v1` as a project extension. This avoids silently changing the research definition.

### 2. Bayesian optimization objective
The methodology mandates Bayesian optimization but does not define its objective. The executable project chooses `mean_recall_at_k` on validation data so the optimizer has a deterministic research target. The choice is recorded in configuration and should be synchronized with the final thesis text if a different objective is intended.

### 3. RGB execution schema
The methodology specifies the four RGB settings and formulas, but it does not specify the exact serialized case schema or how RGB cases are transformed into the project's global corpus/MIGRES input. The project therefore implements a clean evaluator for prepared model outputs rather than inventing an unofficial RGB data-construction protocol. The downstream notebook documents the expected prediction fields.

### 4. Retrieval ground truth by dataset
The methodology says to report only retrieval metrics supported by a dataset's relevance ground truth. The loader derives document IDs directly for HotpotQA/WikiHop supporting facts, MuSiQue supporting paragraphs, and accepts explicit `supporting_doc_ids` / `relevant_docs` annotations for other datasets. Questions without usable relevance annotations are not silently treated as retrieval failures.

### 5. Full-Wikipedia storage is still a hardware constraint
The disk-backed store removes the requirement to materialize all 768-d vectors in process RAM. It does not remove the physical storage requirement. A corpus large enough to require tens of gigabytes of embeddings still needs sufficient SSD capacity (and the methodology's stated 20 GB minimum hardware line should not be interpreted as guaranteeing a full-Wikipedia run).

### 6. Exact software/model versions
The methodology lists specific versions, but the code does not assert that an installation actually has those versions. Real runs record installed package versions and explicit model IDs in run metadata. The LLM model remains configurable through `LLM_MODEL`; there is no silent hard-coded claim about an unverified provider model name.

## Experimental-design gaps closed in revision 0.3

| Area | Resolution |
|---|---|
| Corpus D definition | D is now explicitly a pooled, bounded corpus from training material of WikiHop, HotpotQA, MuSiQue, Natural Questions, TriviaQA and StrategyQA. It is deduplicated, chunked to <=350 tokenizer tokens with 50-token overlap, capped at 100,000 passages, and allocated a deterministic per-dataset quota. |
| Chunking / encoder length | Corpus construction chunks before semantic encoding; the chunk size is below the model input budget rather than relying on silent model truncation. Tokenizer loading occurs once per build. |
| Vector store | Pinecone has been removed. Exact SAR scoring uses the local disk-mapped store because every document must be scored by the composite state-aware equation. |
| Unlabeled test sets | Tuning is a deterministic 10% holdout from train; public dev is the default labeled final split. The actual split and source hash are recorded in metadata. |
| Baseline coverage | Added MMR plus an InfoGain-RAG adapter. InfoGain-RAG is optional because its published method depends on a specialized trained reranker checkpoint; the notebook skips it explicitly if that checkpoint is absent. |
| SAR vs MIGRES filter interaction | Raw retrieval metrics are calculated before the common MIGRES cross-encoder filter. Filter retention and top-1 survival are recorded separately so downstream answer results are not interpreted as raw retriever rankings. |
| Ablation sharpness | Added Gap-Only and Novelty-Only. Question-Only remains a SAR-state control using the original question and is explicitly distinct from the Sentence Transformer Search baseline, which consumes MIGRES-generated query strings. Ablation weights are frozen; no retuning. |
| BO definition | Global tuning across all six datasets; 8 questions/dataset; K in {3,5,10}; 3 initial + 7 Bayesian trials per K; objective is mean final raw Recall@K. |
| Iterative Recall@K | Per-iteration Recall@K is computed from raw retrieval results before filtering. Cumulative recall is a separate union-over-iterations measure in notebook 05. |
| Statistical reporting | Fixed seed is recorded; method comparisons use common-question paired bootstrap CIs and paired randomisation tests. |
| Cost accounting | Added question counts, index-build time, retrieval/embedding/scoring time, documents scored, similarity calculations, iterations to termination, LLM call count, estimated LLM tokens and peak RSS. |
| Accuracy definition | Accuracy is normalized exact-answer correctness with gold aliases; no substring/contains-match or LLM judge. |
| RGB scope | RGB is downstream-only in the current protocol. The project does not silently inject RGB's fixed passages into D; negative rejection is evaluated at the output level because retrieval remains fixed Top-K with no abstention threshold. |

## Baseline comparability rule

The baseline notebook treats the retriever as a plug-in replacement for the complete SAR retrieval component. SAR alone constructs the Sentence Transformer state representations and composite score. Sentence Transformer Search uses the same embedding model but no state-aware score. All other baselines construct their own native lexical, sparse, dense, or late-interaction representation and never instantiate the project's SAR Sentence Transformer.

## Reproducibility notes

Every experimental notebook is independently runnable and defaults to preflight mode. Real runs require the dataset files, corpus D, optional neural model downloads, the official MIGRES repository and LLM credentials as configured. The source code never claims that a particular Python/package/model version is installed merely because the thesis table lists it.
